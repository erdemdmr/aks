Problem:
/home/username/bin is not in your PATH!

Solution:
To do that you need to type in your terminal:
export PATH="$HOME/bin:$PATH"

Problem:
dos2unix: Command not found

Solution:
sudo apt install dos2unix

Problem:
Extension aks-preview is not installed!

Solution:
az extension add --name aks-preview